import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:academix/core/themes/app_colors.dart';
import 'package:academix/core/themes/app_text_styles.dart';
import 'package:academix/core/constants/app_spacing.dart';
import 'package:academix/features/library/presentation/view/ai_chat_screen.dart';
import 'dart:convert';

class PdfAiViewerScreen extends StatefulWidget {
  final String pdfUrl;
  final String title;

  const PdfAiViewerScreen({
    super.key,
    required this.pdfUrl,
    required this.title,
  });

  @override
  State<PdfAiViewerScreen> createState() => _PdfAiViewerScreenState();
}

class _PdfAiViewerScreenState extends State<PdfAiViewerScreen> {
  late final WebViewController _controller;
  bool _loading = true;
  String _selectedText = '';

  @override
  void initState() {
    super.initState();

    const backendBase = 'http://127.0.0.1:8000';

    // Aquí SIEMPRE entra la URL original del recurso
    final proxiedPdfUrl =
        '$backendBase/api/proxy/pdf?url=${Uri.encodeComponent(widget.pdfUrl)}';

    final viewerUrl =
        '$backendBase/api/proxy/pdf-viewer?pdfUrl=${Uri.encodeComponent(proxiedPdfUrl)}';

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel(
        'SelectionChannel',
        onMessageReceived: (message) {
          try {
            final raw = message.message.trim();

            if (raw.startsWith('{')) {
              final data = jsonDecode(raw) as Map<String, dynamic>;
              final type = data['type']?.toString();

              if (type == 'ask_ai') {
                final text = data['text']?.toString().trim() ?? '';
                if (text.isNotEmpty) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AiChatScreen(initialContext: text),
                    ),
                  );
                }
              }
            } else {
              setState(() {
                _selectedText = raw;
              });
            }
          } catch (e) {
            debugPrint('SelectionChannel parse error: $e');
          }
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            setState(() => _loading = true);
          },
          onPageFinished: (_) {
            setState(() => _loading = false);
          },
          onWebResourceError: (error) {
            debugPrint('WEBVIEW ERROR: ${error.description}');
          },
        ),
      );

    _controller.clearCache();
    _controller.loadRequest(Uri.parse(viewerUrl));
  }

 /* void _openAiChat() {
    if (_selectedText.trim().isEmpty) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AiChatScreen(initialContext: _selectedText),
      ),
    );
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        title: Text(
          widget.title,
          style: AppTextStyles.body.copyWith(
            color: AppColors.text,
            fontWeight: FontWeight.w600,
          ),
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_loading) const Center(child: CircularProgressIndicator()),

        ],
      ),
    );
  }
}